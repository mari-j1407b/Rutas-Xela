using System.Globalization;

namespace RutasXela.UI;

public class MainForm : Form
{
    // ═══════════════════════════════════════════════════════════
    //  ► AQUÍ SE CONECTA TU PROYECTO ◄
    //  Cuando tengas tu clase que implemente IRutasService, cambia
    //  esta línea:   new MockRutasService()  →  new TuServicioReal()
    // ═══════════════════════════════════════════════════════════
    private readonly IRutasService _svc = new MockRutasService();

    private MapPanel _map;
    private TextBox _log;

    // Buscar
    private RoundedInput _buscar;
    private ListBox _sug;
    private Label _info;

    // Rutas
    private ComboBox _cO, _cD;
    private RadioButton _rRapida, _rEco;
    private Label _resultado;

    // Registrar parada / ruta
    private RoundedInput _pCod, _pNom, _pLat, _pLon;
    private RoundedInput _rO, _rD, _rT, _rC, _rL;
    private CheckBox _rUno;

    public MainForm()
    {
        Text = "Rutas Xela";
        Size = new Size(1320, 840);
        MinimumSize = new Size(1150, 720);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Theme.Fondo;
        Font = new Font("Segoe UI", 9.5f);

        BuildUI();
        Refrescar();
        Log("Listo. Se cargaron datos de demostración.");
    }

    // ───────────────────────── CONSTRUCCIÓN DE LA UI ─────────────────────────
    private void BuildUI()
    {
        // Encabezado
        var header = new Panel { Dock = DockStyle.Top, Height = 74, BackColor = Theme.Navy };
        header.Controls.Add(new Label
        {
            Text = "Rutas Xela", ForeColor = Color.White, BackColor = Color.Transparent,
            Font = new Font("Segoe UI Semibold", 20f), AutoSize = true, Location = new Point(24, 8)
        });
        header.Controls.Add(new Label
        {
            Text = "Red de transporte urbano · Quetzaltenango", ForeColor = Color.FromArgb(190, 198, 215),
            BackColor = Color.Transparent, Font = new Font("Segoe UI", 9.5f), AutoSize = true, Location = new Point(27, 44)
        });
        var btnCsv = new RoundedButton { Text = "Cargar CSV", Normal = Theme.Amarillo, ForeColor = Theme.Navy, Size = new Size(150, 38), Top = 17 };
        btnCsv.Click += (_, _) => CargarCsv();
        header.Controls.Add(btnCsv);
        header.Resize += (_, _) => { btnCsv.Left = header.Width - btnCsv.Width - 24; header.Invalidate(); };
        header.Paint += (_, e) =>
        {
            int w = header.Width / Theme.Lineas.Length + 1;
            for (int i = 0; i < Theme.Lineas.Length; i++)
            {
                using var b = new SolidBrush(Theme.Lineas[i]);
                e.Graphics.FillRectangle(b, i * w, header.Height - 5, w, 5);
            }
        };

        // Contenido
        var content = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16) };

        // Derecha: mapa + registro
        var right = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 0, 0, 0) };
        _map = new MapPanel { Dock = DockStyle.Fill };
        var spacer = new Panel { Dock = DockStyle.Bottom, Height = 14 };
        var logCard = new RoundedPanel { Dock = DockStyle.Bottom, Height = 170, Padding = new Padding(16, 40, 16, 14) };
        logCard.Controls.Add(new Label
        {
            Text = "Registro de actividad", Font = new Font("Segoe UI Semibold", 11f), ForeColor = Theme.Navy,
            BackColor = Color.White, AutoSize = true, Location = new Point(18, 12)
        });
        _log = new TextBox
        {
            Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, BorderStyle = BorderStyle.None,
            BackColor = Color.White, ForeColor = Theme.Texto, ScrollBars = ScrollBars.Vertical,
            Font = new Font("Consolas", 9.5f)
        };
        logCard.Controls.Add(_log);
        right.Controls.Add(_map);      // Fill primero
        right.Controls.Add(spacer);
        right.Controls.Add(logCard);

        // Izquierda: tarjetas
        var left = new FlowLayoutPanel
        {
            Dock = DockStyle.Left, Width = 396, FlowDirection = FlowDirection.TopDown,
            WrapContents = false, AutoScroll = true
        };
        left.Controls.Add(CardBuscar());
        left.Controls.Add(CardRutas());
        left.Controls.Add(CardParada());
        left.Controls.Add(CardRuta());

        content.Controls.Add(right);   // Fill primero
        content.Controls.Add(left);

        Controls.Add(content);         // Fill primero
        Controls.Add(header);
    }

    // ───────────────────────── TARJETAS ─────────────────────────
    private RoundedPanel Card(string titulo, int alto)
    {
        var c = new RoundedPanel { Width = 360, Height = alto, Margin = new Padding(0, 0, 0, 14) };
        c.Controls.Add(new Label
        {
            Text = titulo, Font = new Font("Segoe UI Semibold", 11.5f), ForeColor = Theme.Navy,
            BackColor = Color.White, AutoSize = true, Location = new Point(18, 14)
        });
        return c;
    }

    private static Label Etiqueta(Control padre, string t, int x, int y)
    {
        var l = new Label { Text = t, ForeColor = Theme.Gris, BackColor = Color.White, AutoSize = true, Location = new Point(x, y), Font = new Font("Segoe UI", 8.5f) };
        padre.Controls.Add(l);
        return l;
    }

    private static RoundedInput Campo(Control padre, int x, int y, int w, string placeholder)
    {
        var tb = new TextBox { PlaceholderText = placeholder };
        var ri = new RoundedInput(tb) { Location = new Point(x, y), Width = w };
        padre.Controls.Add(ri);
        return ri;
    }

    private static ComboBox Combo(Control padre, int x, int y, int w)
    {
        var cb = new ComboBox();
        var ri = new RoundedInput(cb) { Location = new Point(x, y), Width = w };
        padre.Controls.Add(ri);
        return cb;
    }

    private static RoundedButton Boton(Control padre, string t, int x, int y, int w, Color color, Color? fore = null)
    {
        var b = new RoundedButton { Text = t, Normal = color, Location = new Point(x, y), Width = w };
        if (fore.HasValue) b.ForeColor = fore.Value;
        padre.Controls.Add(b);
        return b;
    }

    private RoundedPanel CardBuscar()
    {
        var c = Card("Buscar parada", 275);
        _buscar = Campo(c, 18, 48, 324, "Escribe un código o nombre…");
        _buscar.Inner.TextChanged += (_, _) => Sugerir();
        _buscar.Inner.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter && _sug.Items.Count > 0) { _sug.SelectedIndex = 0; e.SuppressKeyPress = true; }
        };

        _sug = new ListBox
        {
            Location = new Point(22, 98), Size = new Size(316, 96), BorderStyle = BorderStyle.None,
            BackColor = Color.White, ForeColor = Theme.Texto, Font = new Font("Segoe UI", 10f), IntegralHeight = false
        };
        _sug.SelectedIndexChanged += (_, _) => MostrarSeleccion();
        c.Controls.Add(_sug);

        _info = new Label
        {
            Location = new Point(18, 206), Size = new Size(324, 56), BackColor = Color.White,
            ForeColor = Theme.Texto, Text = "Las sugerencias aparecerán mientras escribes."
        };
        c.Controls.Add(_info);
        return c;
    }

    private RoundedPanel CardRutas()
    {
        var c = Card("Rutas y recorridos", 395);
        Etiqueta(c, "ORIGEN", 20, 46);
        _cO = Combo(c, 18, 64, 324);
        Etiqueta(c, "DESTINO", 20, 110);
        _cD = Combo(c, 18, 128, 324);

        _rRapida = new RadioButton { Text = "Más rápida", Checked = true, Location = new Point(20, 182), AutoSize = true, BackColor = Color.White, ForeColor = Theme.Texto };
        _rEco = new RadioButton { Text = "Más económica", Location = new Point(150, 182), AutoSize = true, BackColor = Color.White, ForeColor = Theme.Texto };
        c.Controls.Add(_rRapida);
        c.Controls.Add(_rEco);

        Boton(c, "Calcular ruta", 18, 214, 158, Theme.Navy).Click += (_, _) => Calcular();
        Boton(c, "¿Misma zona?", 184, 214, 158, Theme.Verde).Click += (_, _) => VerificarZona();
        Boton(c, "Recorrido BFS", 18, 258, 158, Theme.Linea(4)).Click += (_, _) => Recorrer(true);
        Boton(c, "Recorrido DFS", 184, 258, 158, Theme.Linea(6)).Click += (_, _) => Recorrer(false);

        _resultado = new Label
        {
            Location = new Point(18, 308), Size = new Size(324, 76), BackColor = Color.White,
            ForeColor = Theme.Texto, Text = "Elige origen y destino para calcular."
        };
        c.Controls.Add(_resultado);
        return c;
    }

    private RoundedPanel CardParada()
    {
        var c = Card("Registrar parada", 215);
        _pCod = Campo(c, 18, 48, 100, "Código");
        _pNom = Campo(c, 126, 48, 216, "Nombre");
        _pLat = Campo(c, 18, 96, 162, "Latitud");
        _pLon = Campo(c, 186, 96, 156, "Longitud");
        Boton(c, "Agregar parada", 18, 152, 324, Theme.Navy).Click += (_, _) => AgregarParada();
        return c;
    }

    private RoundedPanel CardRuta()
    {
        var c = Card("Registrar ruta", 245);
        _rO = Campo(c, 18, 48, 158, "Origen (P001)");
        _rD = Campo(c, 184, 48, 158, "Destino (P002)");
        _rT = Campo(c, 18, 96, 100, "Minutos");
        _rC = Campo(c, 126, 96, 100, "Costo Q");
        _rL = Campo(c, 234, 96, 108, "Línea (1-7)");
        _rUno = new CheckBox { Text = "Solo un sentido", Location = new Point(20, 148), AutoSize = true, BackColor = Color.White, ForeColor = Theme.Texto };
        c.Controls.Add(_rUno);
        Boton(c, "Agregar ruta", 18, 182, 324, Theme.Amarillo, Theme.Navy).Click += (_, _) => AgregarRuta();
        return c;
    }

    // ───────────────────────── LÓGICA DE LA UI ─────────────────────────
    private void Log(string msg) => _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");

    private string Nombre(string codigo) => _svc.BuscarParada(codigo)?.Nombre ?? codigo;

    private void Refrescar()
    {
        var ps = _svc.ObtenerParadas();
        _map.Paradas = ps;
        _map.Rutas = _svc.ObtenerRutas();
        _map.Invalidate();
        LlenarCombo(_cO, ps, 0);
        LlenarCombo(_cD, ps, 1);
    }

    private static void LlenarCombo(ComboBox cb, Parada[] ps, int defecto)
    {
        string prev = (cb.SelectedItem as Parada)?.Codigo;
        cb.Items.Clear();
        cb.Items.AddRange(ps);
        int idx = prev == null ? -1 : Array.FindIndex(ps, p => p.Codigo == prev);
        if (idx < 0) idx = Math.Min(defecto, ps.Length - 1);
        if (idx >= 0) cb.SelectedIndex = idx;
    }

    private bool Seleccion(out string o, out string d)
    {
        o = (_cO.SelectedItem as Parada)?.Codigo;
        d = (_cD.SelectedItem as Parada)?.Codigo;
        if (o == null || d == null) { MessageBox.Show("Selecciona origen y destino."); return false; }
        return true;
    }

    private static bool Dbl(string s, out double v) =>
        double.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v);

    // — Buscar / autocompletado (Trie + Tabla Hash) —
    private void Sugerir()
    {
        _sug.Items.Clear();
        string t = _buscar.Valor.Trim();
        if (t.Length == 0) { _info.Text = "Las sugerencias aparecerán mientras escribes."; return; }
        _sug.Items.AddRange(_svc.Autocompletar(t));
    }

    private void MostrarSeleccion()
    {
        if (_sug.SelectedItem is not Parada sel) return;
        var p = _svc.BuscarParada(sel.Codigo) ?? sel;
        _info.Text = $"{p.Codigo} · {p.Nombre}\nLat {p.Latitud.ToString("F4", CultureInfo.InvariantCulture)}   Lon {p.Longitud.ToString("F4", CultureInfo.InvariantCulture)}";
        _map.Seleccion = p.Codigo;
        _map.Invalidate();
        Log($"Parada localizada: {p}");
    }

    // — Dijkstra (validando antes con Union-Find) —
    private void Calcular()
    {
        if (!Seleccion(out var o, out var d)) return;
        _map.Recorrido = null;

        if (!_svc.MismaZona(o, d))
        {
            _map.Camino = null; _map.Invalidate();
            _resultado.Text = "Las paradas no están en la misma zona conectada.";
            Log($"{Nombre(o)} y {Nombre(d)} NO están conectadas.");
            return;
        }

        var crit = _rEco.Checked ? Criterio.Economica : Criterio.Rapida;
        var r = _svc.CalcularRuta(o, d, crit);
        if (!r.Exito)
        {
            _map.Camino = null; _map.Invalidate();
            _resultado.Text = r.Mensaje;
            Log(r.Mensaje);
            return;
        }

        _map.Camino = r.Camino;
        _map.Invalidate();
        _resultado.Text = "Ruta: " + string.Join(" → ", r.Camino.Select(Nombre)) +
                          $"\nTiempo: {r.TiempoTotal} min   ·   Costo: Q{r.CostoTotal.ToString("F2", CultureInfo.InvariantCulture)}";
        Log($"Ruta {(crit == Criterio.Rapida ? "rápida" : "económica")}: {string.Join(" → ", r.Camino)}");
    }

    // — Union-Find —
    private void VerificarZona()
    {
        if (!Seleccion(out var o, out var d)) return;
        bool ok = _svc.MismaZona(o, d);
        string msg = ok ? $"{Nombre(o)} y {Nombre(d)} están en la MISMA zona conectada."
                        : $"{Nombre(o)} y {Nombre(d)} están en zonas DIFERENTES.";
        _resultado.Text = msg;
        Log(msg);
    }

    // — BFS / DFS —
    private void Recorrer(bool bfs)
    {
        if (!Seleccion(out var o, out _)) return;
        var orden = bfs ? _svc.RecorridoBFS(o) : _svc.RecorridoDFS(o);
        _map.Camino = null;
        _map.Recorrido = orden;
        _map.Invalidate();
        string txt = string.Join(" → ", orden.Select(Nombre));
        _resultado.Text = (bfs ? "BFS: " : "DFS: ") + txt;
        Log((bfs ? "BFS" : "DFS") + " desde " + Nombre(o) + ": " + string.Join(", ", orden));
    }

    // — Registrar —
    private void AgregarParada()
    {
        if (!Dbl(_pLat.Valor, out var lat) || !Dbl(_pLon.Valor, out var lon))
        { MessageBox.Show("Latitud y longitud deben ser números (ej. 14.8347)."); return; }

        var p = new Parada { Codigo = _pCod.Valor.Trim(), Nombre = _pNom.Valor.Trim(), Latitud = lat, Longitud = lon };
        if (_svc.AgregarParada(p))
        {
            Log($"Parada agregada: {p}");
            _pCod.Valor = _pNom.Valor = _pLat.Valor = _pLon.Valor = "";
            Refrescar();
        }
        else MessageBox.Show("No se pudo agregar (¿código vacío o repetido?).");
    }

    private void AgregarRuta()
    {
        if (!int.TryParse(_rT.Valor, out var t) || !Dbl(_rC.Valor, out var costo))
        { MessageBox.Show("Minutos debe ser entero y costo un número."); return; }
        int.TryParse(_rL.Valor, out var linea);
        if (linea < 1) linea = 1;

        string o = _rO.Valor.Trim(), d = _rD.Valor.Trim();
        if (_svc.MismaZona(o, d))
            Log($"Aviso: {o} y {d} ya están en la misma zona; la nueva ruta crea una alternativa.");
        else
            Log($"Aviso: {o} y {d} estaban en zonas distintas; la nueva ruta las une.");

        var r = new Ruta { Origen = o, Destino = d, Tiempo = t, Costo = costo, UnSentido = _rUno.Checked, Linea = linea };
        if (_svc.AgregarRuta(r))
        {
            Log($"Ruta agregada: {r.Origen} → {r.Destino} ({t} min, Q{costo.ToString("F2", CultureInfo.InvariantCulture)})");
            Refrescar();
        }
        else MessageBox.Show("No se pudo agregar la ruta (verifica que ambas paradas existan).");
    }

    // — CSV —
    private void CargarCsv()
    {
        using var dlg = new OpenFileDialog { Filter = "Archivos CSV/TXT|*.csv;*.txt|Todos|*.*", Title = "Selecciona el archivo de datos" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        try
        {
            Log(_svc.CargarCSV(dlg.FileName));
            Refrescar();
        }
        catch (Exception ex) { MessageBox.Show("Error al leer el archivo:\n" + ex.Message); }
    }
}
