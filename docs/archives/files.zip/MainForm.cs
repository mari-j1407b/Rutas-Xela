using System.Globalization;

namespace RutasXela.UI;

// ─────────────────────────────────────────────────────────────
//  LÓGICA de la ventana. El DISEÑO VISUAL está en MainForm.Designer.cs
//  (ábrelo con el diseñador de Visual Studio para editarlo).
// ─────────────────────────────────────────────────────────────
public partial class MainForm : Form
{
    // ═══════════════════════════════════════════════════════════
    //  ► AQUÍ SE CONECTA TU PROYECTO ◄
    //  Cuando tengas tu clase que implemente IRutasService, cambia
    //  esta línea:   new MockRutasService()  →  new TuServicioReal()
    // ═══════════════════════════════════════════════════════════
    private readonly IRutasService _svc = new MockRutasService();

    // Los ComboBox viven dentro de los RoundedComboInput del diseñador
    private ComboBox _cO, _cD;

    public MainForm()
    {
        InitializeComponent();   // ← construye todo el diseño (MainForm.Designer.cs)

        // Conexiones a controles internos (el diseñador no puede guardarlas)
        _cO = cmbOrigen.Combo;
        _cD = cmbDestino.Combo;
        _buscar.Inner.TextChanged += (_, _) => Sugerir();
        _buscar.Inner.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter && _sug.Items.Count > 0) { _sug.SelectedIndex = 0; e.SuppressKeyPress = true; }
        };

        Refrescar();
        Log("Listo. Se cargaron datos de demostración.");
    }

    // ───────────────────────── EVENTOS (enlazados desde el diseñador) ─────────────────────────
    private void Header_Paint(object sender, PaintEventArgs e)
    {
        int w = panelEncabezado.Width / Theme.Lineas.Length + 1;
        for (int i = 0; i < Theme.Lineas.Length; i++)
        {
            using var b = new SolidBrush(Theme.Lineas[i]);
            e.Graphics.FillRectangle(b, i * w, panelEncabezado.Height - 5, w, 5);
        }
    }

    private void Header_Resize(object sender, EventArgs e)
    {
        btnCsv.Left = panelEncabezado.Width - btnCsv.Width - 24;
        panelEncabezado.Invalidate();
    }

    private void BtnCsv_Click(object sender, EventArgs e) => CargarCsv();
    private void BtnCalcular_Click(object sender, EventArgs e) => Calcular();
    private void BtnZona_Click(object sender, EventArgs e) => VerificarZona();
    private void BtnBfs_Click(object sender, EventArgs e) => Recorrer(true);
    private void BtnDfs_Click(object sender, EventArgs e) => Recorrer(false);
    private void BtnAgregarParada_Click(object sender, EventArgs e) => AgregarParada();
    private void BtnAgregarRuta_Click(object sender, EventArgs e) => AgregarRuta();
    private void Sug_SelectedIndexChanged(object sender, EventArgs e) => MostrarSeleccion();

    // ───────────────────────── LÓGICA DE LA UI ─────────────────────────
    private void Log(string msg) => _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");

    private string Nombre(string codigo) => _svc.BuscarParada(codigo)?.Nombre ?? codigo;

    private void Refrescar()
    {
        var ps = _svc.ObtenerParadas();
        _map.Paradas = ps;
        _map.Rutas = _svc.ObtenerRutas();
        _map.Invalidate();
        LlenarCombo(_cO, ps, 0);
        LlenarCombo(_cD, ps, 1);
    }

    private static void LlenarCombo(ComboBox cb, Parada[] ps, int defecto)
    {
        string prev = (cb.SelectedItem as Parada)?.Codigo;
        cb.Items.Clear();
        cb.Items.AddRange(ps);
        int idx = prev == null ? -1 : Array.FindIndex(ps, p => p.Codigo == prev);
        if (idx < 0) idx = Math.Min(defecto, ps.Length - 1);
        if (idx >= 0) cb.SelectedIndex = idx;
    }

    private bool Seleccion(out string o, out string d)
    {
        o = (_cO.SelectedItem as Parada)?.Codigo;
        d = (_cD.SelectedItem as Parada)?.Codigo;
        if (o == null || d == null) { MessageBox.Show("Selecciona origen y destino."); return false; }
        return true;
    }

    private static bool Dbl(string s, out double v) =>
        double.TryParse(s.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out v);

    // — Buscar / autocompletado (Trie + Tabla Hash) —
    private void Sugerir()
    {
        _sug.Items.Clear();
        string t = _buscar.Valor.Trim();
        if (t.Length == 0) { _info.Text = "Las sugerencias aparecerán mientras escribes."; return; }
        _sug.Items.AddRange(_svc.Autocompletar(t));
    }

    private void MostrarSeleccion()
    {
        if (_sug.SelectedItem is not Parada sel) return;
        var p = _svc.BuscarParada(sel.Codigo) ?? sel;
        _info.Text = $"{p.Codigo} · {p.Nombre}\nLat {p.Latitud.ToString("F4", CultureInfo.InvariantCulture)}   Lon {p.Longitud.ToString("F4", CultureInfo.InvariantCulture)}";
        _map.Seleccion = p.Codigo;
        _map.Invalidate();
        Log($"Parada localizada: {p}");
    }

    // — Dijkstra (validando antes con Union-Find) —
    private void Calcular()
    {
        if (!Seleccion(out var o, out var d)) return;
        _map.Recorrido = null;

        if (!_svc.MismaZona(o, d))
        {
            _map.Camino = null; _map.Invalidate();
            _resultado.Text = "Las paradas no están en la misma zona conectada.";
            Log($"{Nombre(o)} y {Nombre(d)} NO están conectadas.");
            return;
        }

        var crit = _rEco.Checked ? Criterio.Economica : Criterio.Rapida;
        var r = _svc.CalcularRuta(o, d, crit);
        if (!r.Exito)
        {
            _map.Camino = null; _map.Invalidate();
            _resultado.Text = r.Mensaje;
            Log(r.Mensaje);
            return;
        }

        _map.Camino = r.Camino;
        _map.Invalidate();
        _resultado.Text = "Ruta: " + string.Join(" → ", r.Camino.Select(Nombre)) +
                          $"\nTiempo: {r.TiempoTotal} min   ·   Costo: Q{r.CostoTotal.ToString("F2", CultureInfo.InvariantCulture)}";
        Log($"Ruta {(crit == Criterio.Rapida ? "rápida" : "económica")}: {string.Join(" → ", r.Camino)}");
    }

    // — Union-Find —
    private void VerificarZona()
    {
        if (!Seleccion(out var o, out var d)) return;
        bool ok = _svc.MismaZona(o, d);
        string msg = ok ? $"{Nombre(o)} y {Nombre(d)} están en la MISMA zona conectada."
                        : $"{Nombre(o)} y {Nombre(d)} están en zonas DIFERENTES.";
        _resultado.Text = msg;
        Log(msg);
    }

    // — BFS / DFS —
    private void Recorrer(bool bfs)
    {
        if (!Seleccion(out var o, out _)) return;
        var orden = bfs ? _svc.RecorridoBFS(o) : _svc.RecorridoDFS(o);
        _map.Camino = null;
        _map.Recorrido = orden;
        _map.Invalidate();
        string txt = string.Join(" → ", orden.Select(Nombre));
        _resultado.Text = (bfs ? "BFS: " : "DFS: ") + txt;
        Log((bfs ? "BFS" : "DFS") + " desde " + Nombre(o) + ": " + string.Join(", ", orden));
    }

    // — Registrar —
    private void AgregarParada()
    {
        if (!Dbl(_pLat.Valor, out var lat) || !Dbl(_pLon.Valor, out var lon))
        { MessageBox.Show("Latitud y longitud deben ser números (ej. 14.8347)."); return; }

        var p = new Parada { Codigo = _pCod.Valor.Trim(), Nombre = _pNom.Valor.Trim(), Latitud = lat, Longitud = lon };
        if (_svc.AgregarParada(p))
        {
            Log($"Parada agregada: {p}");
            _pCod.Valor = _pNom.Valor = _pLat.Valor = _pLon.Valor = "";
            Refrescar();
        }
        else MessageBox.Show("No se pudo agregar (¿código vacío o repetido?).");
    }

    private void AgregarRuta()
    {
        if (!int.TryParse(_rT.Valor, out var t) || !Dbl(_rC.Valor, out var costo))
        { MessageBox.Show("Minutos debe ser entero y costo un número."); return; }
        int.TryParse(_rL.Valor, out var linea);
        if (linea < 1) linea = 1;

        string o = _rO.Valor.Trim(), d = _rD.Valor.Trim();
        if (_svc.MismaZona(o, d))
            Log($"Aviso: {o} y {d} ya están en la misma zona; la nueva ruta crea una alternativa.");
        else
            Log($"Aviso: {o} y {d} estaban en zonas distintas; la nueva ruta las une.");

        var r = new Ruta { Origen = o, Destino = d, Tiempo = t, Costo = costo, UnSentido = _rUno.Checked, Linea = linea };
        if (_svc.AgregarRuta(r))
        {
            Log($"Ruta agregada: {r.Origen} → {r.Destino} ({t} min, Q{costo.ToString("F2", CultureInfo.InvariantCulture)})");
            Refrescar();
        }
        else MessageBox.Show("No se pudo agregar la ruta (verifica que ambas paradas existan).");
    }

    // — CSV —
    private void CargarCsv()
    {
        using var dlg = new OpenFileDialog { Filter = "Archivos CSV/TXT|*.csv;*.txt|Todos|*.*", Title = "Selecciona el archivo de datos" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        try
        {
            Log(_svc.CargarCSV(dlg.FileName));
            Refrescar();
        }
        catch (Exception ex) { MessageBox.Show("Error al leer el archivo:\n" + ex.Message); }
    }
}
