namespace RutasXela.UI
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelEncabezado = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.btnCsv = new RutasXela.UI.RoundedButton();
            this.panelContenido = new System.Windows.Forms.Panel();
            this.panelDerecho = new System.Windows.Forms.Panel();
            this._map = new RutasXela.UI.MapPanel();
            this.espaciador = new System.Windows.Forms.Panel();
            this.logCard = new RutasXela.UI.RoundedPanel();
            this.lblLogTitulo = new System.Windows.Forms.Label();
            this._log = new System.Windows.Forms.TextBox();
            this.panelIzquierdo = new System.Windows.Forms.FlowLayoutPanel();
            this.cardBuscar = new RutasXela.UI.RoundedPanel();
            this.lblTituloBuscar = new System.Windows.Forms.Label();
            this._buscar = new RutasXela.UI.RoundedInput();
            this._sug = new System.Windows.Forms.ListBox();
            this._info = new System.Windows.Forms.Label();
            this.cardRutas = new RutasXela.UI.RoundedPanel();
            this.lblTituloRutas = new System.Windows.Forms.Label();
            this.lblOrigen = new System.Windows.Forms.Label();
            this.cmbOrigen = new RutasXela.UI.RoundedComboInput();
            this.lblDestino = new System.Windows.Forms.Label();
            this.cmbDestino = new RutasXela.UI.RoundedComboInput();
            this._rRapida = new System.Windows.Forms.RadioButton();
            this._rEco = new System.Windows.Forms.RadioButton();
            this.btnCalcular = new RutasXela.UI.RoundedButton();
            this.btnZona = new RutasXela.UI.RoundedButton();
            this.btnBfs = new RutasXela.UI.RoundedButton();
            this.btnDfs = new RutasXela.UI.RoundedButton();
            this._resultado = new System.Windows.Forms.Label();
            this.cardParada = new RutasXela.UI.RoundedPanel();
            this.lblTituloParada = new System.Windows.Forms.Label();
            this._pCod = new RutasXela.UI.RoundedInput();
            this._pNom = new RutasXela.UI.RoundedInput();
            this._pLat = new RutasXela.UI.RoundedInput();
            this._pLon = new RutasXela.UI.RoundedInput();
            this.btnAgregarParada = new RutasXela.UI.RoundedButton();
            this.cardRuta = new RutasXela.UI.RoundedPanel();
            this.lblTituloRuta = new System.Windows.Forms.Label();
            this._rO = new RutasXela.UI.RoundedInput();
            this._rD = new RutasXela.UI.RoundedInput();
            this._rT = new RutasXela.UI.RoundedInput();
            this._rC = new RutasXela.UI.RoundedInput();
            this._rL = new RutasXela.UI.RoundedInput();
            this._rUno = new System.Windows.Forms.CheckBox();
            this.btnAgregarRuta = new RutasXela.UI.RoundedButton();
            this.panelEncabezado.SuspendLayout();
            this.panelContenido.SuspendLayout();
            this.panelDerecho.SuspendLayout();
            this.logCard.SuspendLayout();
            this.panelIzquierdo.SuspendLayout();
            this.cardBuscar.SuspendLayout();
            this.cardRutas.SuspendLayout();
            this.cardParada.SuspendLayout();
            this.cardRuta.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelEncabezado
            // 
            this.panelEncabezado.BackColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.panelEncabezado.Controls.Add(this.lblTitulo);
            this.panelEncabezado.Controls.Add(this.lblSubtitulo);
            this.panelEncabezado.Controls.Add(this.btnCsv);
            this.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEncabezado.Name = "panelEncabezado";
            this.panelEncabezado.Size = new System.Drawing.Size(1304, 74);
            this.panelEncabezado.Paint += new System.Windows.Forms.PaintEventHandler(this.Header_Paint);
            this.panelEncabezado.Resize += new System.EventHandler(this.Header_Resize);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(24, 8);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "Rutas Xela";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(190, 198, 215);
            this.lblSubtitulo.Location = new System.Drawing.Point(27, 44);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.Text = "Red de transporte urbano · Quetzaltenango";
            // 
            // btnCsv
            // 
            this.btnCsv.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.btnCsv.Location = new System.Drawing.Point(1130, 17);
            this.btnCsv.Name = "btnCsv";
            this.btnCsv.Normal = System.Drawing.Color.FromArgb(247, 196, 0);
            this.btnCsv.Size = new System.Drawing.Size(150, 38);
            this.btnCsv.Text = "Cargar CSV";
            this.btnCsv.Click += new System.EventHandler(this.BtnCsv_Click);
            // 
            // panelContenido
            // 
            this.panelContenido.Controls.Add(this.panelDerecho);
            this.panelContenido.Controls.Add(this.panelIzquierdo);
            this.panelContenido.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenido.Name = "panelContenido";
            this.panelContenido.Padding = new System.Windows.Forms.Padding(16);
            // 
            // panelDerecho
            // 
            this.panelDerecho.Controls.Add(this._map);
            this.panelDerecho.Controls.Add(this.espaciador);
            this.panelDerecho.Controls.Add(this.logCard);
            this.panelDerecho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDerecho.Name = "panelDerecho";
            this.panelDerecho.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            // 
            // _map
            // 
            this._map.Dock = System.Windows.Forms.DockStyle.Fill;
            this._map.Name = "_map";
            // 
            // espaciador
            // 
            this.espaciador.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.espaciador.Name = "espaciador";
            this.espaciador.Size = new System.Drawing.Size(100, 14);
            // 
            // logCard
            // 
            this.logCard.Controls.Add(this.lblLogTitulo);
            this.logCard.Controls.Add(this._log);
            this.logCard.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logCard.Name = "logCard";
            this.logCard.Padding = new System.Windows.Forms.Padding(16, 40, 16, 14);
            this.logCard.Size = new System.Drawing.Size(100, 170);
            // 
            // lblLogTitulo
            // 
            this.lblLogTitulo.AutoSize = true;
            this.lblLogTitulo.BackColor = System.Drawing.Color.White;
            this.lblLogTitulo.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblLogTitulo.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.lblLogTitulo.Location = new System.Drawing.Point(18, 12);
            this.lblLogTitulo.Name = "lblLogTitulo";
            this.lblLogTitulo.Text = "Registro de actividad";
            // 
            // _log
            // 
            this._log.BackColor = System.Drawing.Color.White;
            this._log.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._log.Dock = System.Windows.Forms.DockStyle.Fill;
            this._log.Font = new System.Drawing.Font("Consolas", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this._log.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._log.Multiline = true;
            this._log.Name = "_log";
            this._log.ReadOnly = true;
            this._log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            // 
            // panelIzquierdo
            // 
            this.panelIzquierdo.AutoScroll = true;
            this.panelIzquierdo.Controls.Add(this.cardBuscar);
            this.panelIzquierdo.Controls.Add(this.cardRutas);
            this.panelIzquierdo.Controls.Add(this.cardParada);
            this.panelIzquierdo.Controls.Add(this.cardRuta);
            this.panelIzquierdo.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelIzquierdo.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelIzquierdo.Name = "panelIzquierdo";
            this.panelIzquierdo.Size = new System.Drawing.Size(396, 100);
            this.panelIzquierdo.WrapContents = false;
            // 
            // cardBuscar
            // 
            this.cardBuscar.Controls.Add(this.lblTituloBuscar);
            this.cardBuscar.Controls.Add(this._buscar);
            this.cardBuscar.Controls.Add(this._sug);
            this.cardBuscar.Controls.Add(this._info);
            this.cardBuscar.Margin = new System.Windows.Forms.Padding(0, 0, 0, 14);
            this.cardBuscar.Name = "cardBuscar";
            this.cardBuscar.Size = new System.Drawing.Size(360, 275);
            // 
            // lblTituloBuscar
            // 
            this.lblTituloBuscar.AutoSize = true;
            this.lblTituloBuscar.BackColor = System.Drawing.Color.White;
            this.lblTituloBuscar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTituloBuscar.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.lblTituloBuscar.Location = new System.Drawing.Point(18, 14);
            this.lblTituloBuscar.Name = "lblTituloBuscar";
            this.lblTituloBuscar.Text = "Buscar parada";
            // 
            // _buscar
            // 
            this._buscar.Location = new System.Drawing.Point(18, 48);
            this._buscar.Name = "_buscar";
            this._buscar.Placeholder = "Escribe un código o nombre…";
            this._buscar.Size = new System.Drawing.Size(324, 40);
            // 
            // _sug
            // 
            this._sug.BackColor = System.Drawing.Color.White;
            this._sug.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._sug.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this._sug.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._sug.IntegralHeight = false;
            this._sug.Location = new System.Drawing.Point(22, 98);
            this._sug.Name = "_sug";
            this._sug.Size = new System.Drawing.Size(316, 96);
            this._sug.SelectedIndexChanged += new System.EventHandler(this.Sug_SelectedIndexChanged);
            // 
            // _info
            // 
            this._info.BackColor = System.Drawing.Color.White;
            this._info.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._info.Location = new System.Drawing.Point(18, 206);
            this._info.Name = "_info";
            this._info.Size = new System.Drawing.Size(324, 56);
            this._info.Text = "Las sugerencias aparecerán mientras escribes.";
            // 
            // cardRutas
            // 
            this.cardRutas.Controls.Add(this.lblTituloRutas);
            this.cardRutas.Controls.Add(this.lblOrigen);
            this.cardRutas.Controls.Add(this.cmbOrigen);
            this.cardRutas.Controls.Add(this.lblDestino);
            this.cardRutas.Controls.Add(this.cmbDestino);
            this.cardRutas.Controls.Add(this._rRapida);
            this.cardRutas.Controls.Add(this._rEco);
            this.cardRutas.Controls.Add(this.btnCalcular);
            this.cardRutas.Controls.Add(this.btnZona);
            this.cardRutas.Controls.Add(this.btnBfs);
            this.cardRutas.Controls.Add(this.btnDfs);
            this.cardRutas.Controls.Add(this._resultado);
            this.cardRutas.Margin = new System.Windows.Forms.Padding(0, 0, 0, 14);
            this.cardRutas.Name = "cardRutas";
            this.cardRutas.Size = new System.Drawing.Size(360, 395);
            // 
            // lblTituloRutas
            // 
            this.lblTituloRutas.AutoSize = true;
            this.lblTituloRutas.BackColor = System.Drawing.Color.White;
            this.lblTituloRutas.Font = new System.Drawing.Font("Segoe UI Semibold", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTituloRutas.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.lblTituloRutas.Location = new System.Drawing.Point(18, 14);
            this.lblTituloRutas.Name = "lblTituloRutas";
            this.lblTituloRutas.Text = "Rutas y recorridos";
            // 
            // lblOrigen
            // 
            this.lblOrigen.AutoSize = true;
            this.lblOrigen.BackColor = System.Drawing.Color.White;
            this.lblOrigen.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOrigen.ForeColor = System.Drawing.Color.FromArgb(123, 132, 153);
            this.lblOrigen.Location = new System.Drawing.Point(20, 46);
            this.lblOrigen.Name = "lblOrigen";
            this.lblOrigen.Text = "ORIGEN";
            // 
            // cmbOrigen
            // 
            this.cmbOrigen.Location = new System.Drawing.Point(18, 64);
            this.cmbOrigen.Name = "cmbOrigen";
            this.cmbOrigen.Size = new System.Drawing.Size(324, 40);
            // 
            // lblDestino
            // 
            this.lblDestino.AutoSize = true;
            this.lblDestino.BackColor = System.Drawing.Color.White;
            this.lblDestino.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDestino.ForeColor = System.Drawing.Color.FromArgb(123, 132, 153);
            this.lblDestino.Location = new System.Drawing.Point(20, 110);
            this.lblDestino.Name = "lblDestino";
            this.lblDestino.Text = "DESTINO";
            // 
            // cmbDestino
            // 
            this.cmbDestino.Location = new System.Drawing.Point(18, 128);
            this.cmbDestino.Name = "cmbDestino";
            this.cmbDestino.Size = new System.Drawing.Size(324, 40);
            // 
            // _rRapida
            // 
            this._rRapida.AutoSize = true;
            this._rRapida.BackColor = System.Drawing.Color.White;
            this._rRapida.Checked = true;
            this._rRapida.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._rRapida.Location = new System.Drawing.Point(20, 182);
            this._rRapida.Name = "_rRapida";
            this._rRapida.TabStop = true;
            this._rRapida.Text = "Más rápida";
            // 
            // _rEco
            // 
            this._rEco.AutoSize = true;
            this._rEco.BackColor = System.Drawing.Color.White;
            this._rEco.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._rEco.Location = new System.Drawing.Point(150, 182);
            this._rEco.Name = "_rEco";
            this._rEco.Text = "Más económica";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(18, 214);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Normal = System.Drawing.Color.FromArgb(31, 42, 68);
            this.btnCalcular.Size = new System.Drawing.Size(158, 38);
            this.btnCalcular.Text = "Calcular ruta";
            this.btnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // btnZona
            // 
            this.btnZona.Location = new System.Drawing.Point(184, 214);
            this.btnZona.Name = "btnZona";
            this.btnZona.Normal = System.Drawing.Color.FromArgb(47, 177, 112);
            this.btnZona.Size = new System.Drawing.Size(158, 38);
            this.btnZona.Text = "¿Misma zona?";
            this.btnZona.Click += new System.EventHandler(this.BtnZona_Click);
            // 
            // btnBfs
            // 
            this.btnBfs.Location = new System.Drawing.Point(18, 258);
            this.btnBfs.Name = "btnBfs";
            this.btnBfs.Normal = System.Drawing.Color.FromArgb(123, 94, 167);
            this.btnBfs.Size = new System.Drawing.Size(158, 38);
            this.btnBfs.Text = "Recorrido BFS";
            this.btnBfs.Click += new System.EventHandler(this.BtnBfs_Click);
            // 
            // btnDfs
            // 
            this.btnDfs.Location = new System.Drawing.Point(184, 258);
            this.btnDfs.Name = "btnDfs";
            this.btnDfs.Normal = System.Drawing.Color.FromArgb(194, 21, 140);
            this.btnDfs.Size = new System.Drawing.Size(158, 38);
            this.btnDfs.Text = "Recorrido DFS";
            this.btnDfs.Click += new System.EventHandler(this.BtnDfs_Click);
            // 
            // _resultado
            // 
            this._resultado.BackColor = System.Drawing.Color.White;
            this._resultado.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._resultado.Location = new System.Drawing.Point(18, 308);
            this._resultado.Name = "_resultado";
            this._resultado.Size = new System.Drawing.Size(324, 76);
            this._resultado.Text = "Elige origen y destino para calcular.";
            // 
            // cardParada
            // 
            this.cardParada.Controls.Add(this.lblTituloParada);
            this.cardParada.Controls.Add(this._pCod);
            this.cardParada.Controls.Add(this._pNom);
            this.cardParada.Controls.Add(this._pLat);
            this.cardParada.Controls.Add(this._pLon);
            this.cardParada.Controls.Add(this.btnAgregarParada);
            this.cardParada.Margin = new System.Windows.Forms.Padding(0, 0, 0, 14);
            this.cardParada.Name = "cardParada";
            this.cardParada.Size = new System.Drawing.Size(360, 215);
            // 
            // lblTituloParada
            // 
            this.lblTituloParada.AutoSize = true;
            this.lblTituloParada.BackColor = System.Drawing.Color.White;
            this.lblTituloParada.Font = new System.Drawing.Font("Segoe UI Semibold", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTituloParada.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.lblTituloParada.Location = new System.Drawing.Point(18, 14);
            this.lblTituloParada.Name = "lblTituloParada";
            this.lblTituloParada.Text = "Registrar parada";
            // 
            // _pCod
            // 
            this._pCod.Location = new System.Drawing.Point(18, 48);
            this._pCod.Name = "_pCod";
            this._pCod.Placeholder = "Código";
            this._pCod.Size = new System.Drawing.Size(100, 40);
            // 
            // _pNom
            // 
            this._pNom.Location = new System.Drawing.Point(126, 48);
            this._pNom.Name = "_pNom";
            this._pNom.Placeholder = "Nombre";
            this._pNom.Size = new System.Drawing.Size(216, 40);
            // 
            // _pLat
            // 
            this._pLat.Location = new System.Drawing.Point(18, 96);
            this._pLat.Name = "_pLat";
            this._pLat.Placeholder = "Latitud";
            this._pLat.Size = new System.Drawing.Size(162, 40);
            // 
            // _pLon
            // 
            this._pLon.Location = new System.Drawing.Point(186, 96);
            this._pLon.Name = "_pLon";
            this._pLon.Placeholder = "Longitud";
            this._pLon.Size = new System.Drawing.Size(156, 40);
            // 
            // btnAgregarParada
            // 
            this.btnAgregarParada.Location = new System.Drawing.Point(18, 152);
            this.btnAgregarParada.Name = "btnAgregarParada";
            this.btnAgregarParada.Normal = System.Drawing.Color.FromArgb(31, 42, 68);
            this.btnAgregarParada.Size = new System.Drawing.Size(324, 38);
            this.btnAgregarParada.Text = "Agregar parada";
            this.btnAgregarParada.Click += new System.EventHandler(this.BtnAgregarParada_Click);
            // 
            // cardRuta
            // 
            this.cardRuta.Controls.Add(this.lblTituloRuta);
            this.cardRuta.Controls.Add(this._rO);
            this.cardRuta.Controls.Add(this._rD);
            this.cardRuta.Controls.Add(this._rT);
            this.cardRuta.Controls.Add(this._rC);
            this.cardRuta.Controls.Add(this._rL);
            this.cardRuta.Controls.Add(this._rUno);
            this.cardRuta.Controls.Add(this.btnAgregarRuta);
            this.cardRuta.Margin = new System.Windows.Forms.Padding(0, 0, 0, 14);
            this.cardRuta.Name = "cardRuta";
            this.cardRuta.Size = new System.Drawing.Size(360, 245);
            // 
            // lblTituloRuta
            // 
            this.lblTituloRuta.AutoSize = true;
            this.lblTituloRuta.BackColor = System.Drawing.Color.White;
            this.lblTituloRuta.Font = new System.Drawing.Font("Segoe UI Semibold", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTituloRuta.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.lblTituloRuta.Location = new System.Drawing.Point(18, 14);
            this.lblTituloRuta.Name = "lblTituloRuta";
            this.lblTituloRuta.Text = "Registrar ruta";
            // 
            // _rO
            // 
            this._rO.Location = new System.Drawing.Point(18, 48);
            this._rO.Name = "_rO";
            this._rO.Placeholder = "Origen (P001)";
            this._rO.Size = new System.Drawing.Size(158, 40);
            // 
            // _rD
            // 
            this._rD.Location = new System.Drawing.Point(184, 48);
            this._rD.Name = "_rD";
            this._rD.Placeholder = "Destino (P002)";
            this._rD.Size = new System.Drawing.Size(158, 40);
            // 
            // _rT
            // 
            this._rT.Location = new System.Drawing.Point(18, 96);
            this._rT.Name = "_rT";
            this._rT.Placeholder = "Minutos";
            this._rT.Size = new System.Drawing.Size(100, 40);
            // 
            // _rC
            // 
            this._rC.Location = new System.Drawing.Point(126, 96);
            this._rC.Name = "_rC";
            this._rC.Placeholder = "Costo Q";
            this._rC.Size = new System.Drawing.Size(100, 40);
            // 
            // _rL
            // 
            this._rL.Location = new System.Drawing.Point(234, 96);
            this._rL.Name = "_rL";
            this._rL.Placeholder = "Línea (1-7)";
            this._rL.Size = new System.Drawing.Size(108, 40);
            // 
            // _rUno
            // 
            this._rUno.AutoSize = true;
            this._rUno.BackColor = System.Drawing.Color.White;
            this._rUno.ForeColor = System.Drawing.Color.FromArgb(43, 50, 69);
            this._rUno.Location = new System.Drawing.Point(20, 148);
            this._rUno.Name = "_rUno";
            this._rUno.Text = "Solo un sentido";
            // 
            // btnAgregarRuta
            // 
            this.btnAgregarRuta.ForeColor = System.Drawing.Color.FromArgb(31, 42, 68);
            this.btnAgregarRuta.Location = new System.Drawing.Point(18, 182);
            this.btnAgregarRuta.Name = "btnAgregarRuta";
            this.btnAgregarRuta.Normal = System.Drawing.Color.FromArgb(247, 196, 0);
            this.btnAgregarRuta.Size = new System.Drawing.Size(324, 38);
            this.btnAgregarRuta.Text = "Agregar ruta";
            this.btnAgregarRuta.Click += new System.EventHandler(this.BtnAgregarRuta_Click);
            // 
            // MainForm
            // 
            this.BackColor = System.Drawing.Color.FromArgb(244, 245, 250);
            this.Controls.Add(this.panelContenido);
            this.Controls.Add(this.panelEncabezado);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MinimumSize = new System.Drawing.Size(1150, 720);
            this.Name = "MainForm";
            this.Size = new System.Drawing.Size(1320, 840);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rutas Xela";
            this.panelEncabezado.ResumeLayout(false);
            this.panelEncabezado.PerformLayout();
            this.panelContenido.ResumeLayout(false);
            this.panelDerecho.ResumeLayout(false);
            this.logCard.ResumeLayout(false);
            this.logCard.PerformLayout();
            this.panelIzquierdo.ResumeLayout(false);
            this.cardBuscar.ResumeLayout(false);
            this.cardBuscar.PerformLayout();
            this.cardRutas.ResumeLayout(false);
            this.cardRutas.PerformLayout();
            this.cardParada.ResumeLayout(false);
            this.cardParada.PerformLayout();
            this.cardRuta.ResumeLayout(false);
            this.cardRuta.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelEncabezado;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblSubtitulo;
        private RutasXela.UI.RoundedButton btnCsv;
        private System.Windows.Forms.Panel panelContenido;
        private System.Windows.Forms.Panel panelDerecho;
        private RutasXela.UI.MapPanel _map;
        private System.Windows.Forms.Panel espaciador;
        private RutasXela.UI.RoundedPanel logCard;
        private System.Windows.Forms.Label lblLogTitulo;
        private System.Windows.Forms.TextBox _log;
        private System.Windows.Forms.FlowLayoutPanel panelIzquierdo;
        private RutasXela.UI.RoundedPanel cardBuscar;
        private System.Windows.Forms.Label lblTituloBuscar;
        private RutasXela.UI.RoundedInput _buscar;
        private System.Windows.Forms.ListBox _sug;
        private System.Windows.Forms.Label _info;
        private RutasXela.UI.RoundedPanel cardRutas;
        private System.Windows.Forms.Label lblTituloRutas;
        private System.Windows.Forms.Label lblOrigen;
        private RutasXela.UI.RoundedComboInput cmbOrigen;
        private System.Windows.Forms.Label lblDestino;
        private RutasXela.UI.RoundedComboInput cmbDestino;
        private System.Windows.Forms.RadioButton _rRapida;
        private System.Windows.Forms.RadioButton _rEco;
        private RutasXela.UI.RoundedButton btnCalcular;
        private RutasXela.UI.RoundedButton btnZona;
        private RutasXela.UI.RoundedButton btnBfs;
        private RutasXela.UI.RoundedButton btnDfs;
        private System.Windows.Forms.Label _resultado;
        private RutasXela.UI.RoundedPanel cardParada;
        private System.Windows.Forms.Label lblTituloParada;
        private RutasXela.UI.RoundedInput _pCod;
        private RutasXela.UI.RoundedInput _pNom;
        private RutasXela.UI.RoundedInput _pLat;
        private RutasXela.UI.RoundedInput _pLon;
        private RutasXela.UI.RoundedButton btnAgregarParada;
        private RutasXela.UI.RoundedPanel cardRuta;
        private System.Windows.Forms.Label lblTituloRuta;
        private RutasXela.UI.RoundedInput _rO;
        private RutasXela.UI.RoundedInput _rD;
        private RutasXela.UI.RoundedInput _rT;
        private RutasXela.UI.RoundedInput _rC;
        private RutasXela.UI.RoundedInput _rL;
        private System.Windows.Forms.CheckBox _rUno;
        private RutasXela.UI.RoundedButton btnAgregarRuta;
    }
}
